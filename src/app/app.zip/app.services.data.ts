import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable,throwError } from "rxjs";
import { catchError,retry } from "rxjs/operators";

@Injectable({
    providedIn:'root'
})
export class DataService{

    private urlAPI = "http://localhost/restGSB"

    constructor(private http: HttpClient){ }

    public connexion(login: string, mdp: string){
        let url = this.urlAPI + "/connexion?login="+ login +"&mdp=" +mdp;
        let req = this.http.get<string>(url);
        return req;
    }

    public chargerMedecins(nomMedecin : string){
        let url = this.urlAPI + "/medecins?nom="+ nomMedecin;
        let req = this.http.get<Array<any>>(url);
        return req;
    }

    public chargerRapports(idMedecin : number){
        let url = this.urlAPI + "/rapport/"+ idMedecin;
        let req = this.http.get<Array<any>>(url);
        return req;
    }

    /*

    public majMedecin(id : string ,adresse : string, tel :string, spe : string) {
        let url : string =  this.urlAPI + "/majmedecin?id=" + id + '&adresse="';
            url += adresse + '"&tel=' + tel +"&specialite=" + spe;
            console.log(url)
        let req = this.http.get(url);
     return req;
}*/

public majMedecin(idmed: string, adressemed: string, telmed: string, spemed: string) {

    const body = {
        id:idmed,
        adresse:adressemed,
        tel:telmed,
        specialite:spemed
    };
    console.table(body);
    let url : string = this.urlAPI +"/majMedecin";
    let req = this.http.put<Array<any>>(url,body);
    return req;
  }
  
}