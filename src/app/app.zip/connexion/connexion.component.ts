import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';
import { HttpModule } from '@angular/http';
import { DataService } from '../app.services.data';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-connexion',
  templateUrl: './connexion.component.html',
  styleUrls: ['./connexion.component.scss']
})
export class ConnexionComponent implements OnInit {

  login: any;
  mdp: any;
  estCache : boolean = true;
  lblMessage : string = "";
  visiteur:any;


  constructor(private router: Router, private dataService: DataService ) {}


    valider(){
      
      this.dataService.connexion(this.login,this.mdp).subscribe({
        next : (data)=>{
          console.log(data)
          console.log("ok");
          this.router.navigate(['accueil']);
    
          this.lblMessage="";
          this.estCache=true;
        },
        error : (error) =>{
          console.log('error :', JSON.stringify(error))
          console.log("erreur");
          this.lblMessage="Erreur identifiant/Mot de passe incorrect";
          this.estCache=false;
          alert("Mauvais mots de passe");
        }
      });
      /*if(this.login !="toto" || this.password !="titi"){
        console.log("erreur");
        this.lblMessage="Erreur identifiant/Mot de passe incorrect";
        this.estCache=false;
        alert("Mauvais mots de passe");

    }else{
        console.log("ok");
        this.router.navigate(['accueil']);
  
        this.lblMessage="";
        this.estCache=true;
    }*/
      
      
  
    }
 
    ngOnInit(): void {
      throw new Error('Method not implemented.');
    }


  }
  
  



      /*this.route.paramMap.pipe(this.login,this.password)
                            .subscribe(
                              (data)=>{
                                console.table(data);
                              }
                            )*/
                                

                                

                              
                              

                            
                            
   /*if(this.login !="toto" || this.password !="titi"){
        console.log("erreur");
        this.lblMessage="Erreur identifiant/Mot de passe incorrect";
        this.estCache=false;
        alert("Mauvais mots de passe");

    }else{
        console.log("ok");
        this.router.navigate(['accueil']);
  
        this.lblMessage="";
        this.estCache=true;
    }
      
      
  }
  ngOnInit(): void {

  }
  */
  



function valider() {
  throw new Error('Function not implemented.');
}