import { Component, OnInit } from '@angular/core';
import { Router } from 'express';
import { DataService } from '../app.services.data';
@Component({
  selector: 'app-medecins',
  templateUrl: './medecins.component.html',
  styleUrls: ['./medecins.component.scss']
})
export class MedecinsComponent implements OnInit {
  nomMedecin!: string;
  lesMedecins: Array<any> = new Array;
  estCacheMenu: any;
  medecin : any;
  idMedecin! :number;
  afficherRapports! : any;
  lesRapports: Array<any> = new Array;
  afficherMedecin : any;
  afficherMessage : any;
  lblMessage : string = "";
  afficherListe : any;
 
  

  constructor(private dataService: DataService ) {}

  ngOnInit(): void {
  }

  charger(){
    
    this.dataService.chargerMedecins(this.nomMedecin).subscribe({
      next:(data) => {
        console.log(data);
        this.afficherListe=true;
        this.lesMedecins = data;
        
        
       
      },
      error : (error) => {
        console.log(error);
      }
    });
  }

  derniersRapports(){
    console.log("fonction lancé")
    this.dataService.chargerRapports(this.medecin.id).subscribe({
      next: (data) => {
       
        
        this.lesRapports = Array.of(data); 
        this.afficherRapports = true;
        console.table(this.lesRapports);
        
        
        
      },
      error: (error) => {
        console.log(error);
      },
    });
  }
  

 
  majMedecin() : void{
    this.afficherRapports = false;
    this.afficherMedecin = true;
    this.afficherMessage = false;

}
 valider(): void{
       this.afficherMessage = true;
        this.dataService.majMedecin(this.medecin.id,this.medecin.adresse,this.medecin.tel,this.medecin.specialitecomplementaire)
                                  .subscribe( 
                                      (data)=>{ console.log(data);this.lblMessage= "Enregistrement effectué";
                                         }
                                      ,(error)=>{console.log(error);this.lblMessage= "Merci de réessayer plus tard";}
                                              );
   }

  selectionner(med: any) : void {


      
      this.medecin = med;
      this.nomMedecin = med.nom + " " + med.prenom+ " ;dep :"+med.departement;
      this.idMedecin = med.id;
      this.afficherListe=false;
  
    }
  


}