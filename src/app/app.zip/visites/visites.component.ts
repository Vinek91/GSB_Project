import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visites',
  templateUrl: './visites.component.html',
  styleUrls: ['./visites.component.scss']
})
export class VisitesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
